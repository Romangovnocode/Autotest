# My Python Test Automation course repository

---

### [Link to course playlist](https://www.youtube.com/playlist?list=PL8jIzbooWPdXN6thJ_bGnd9uZjby07DPC)

---

### In this course I automate the UI of the demoqa.com 

### The goal of my course is to help beginner automators create a project for their portfolio

#### *This will be interesting. Let's get started!*
#### 
